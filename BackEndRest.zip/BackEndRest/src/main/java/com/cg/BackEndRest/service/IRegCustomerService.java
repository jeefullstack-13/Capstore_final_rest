package com.cg.BackEndRest.service;

import java.util.List;

import com.cg.BackEndRest.model.Customer;
import com.cg.BackEndRest.model.Merchant;

public interface IRegCustomerService {
	public void saveCustomer(Customer customer);
	public List<Customer> getAllCustomers();
	public Customer getValidCustomer(String username, String password);
	
}
