package com.cg.BackEndRest.service;

import java.util.List;

import com.cg.BackEndRest.model.Address;



public interface IAddressService {

	public List<Address> getAllAddress();
}
