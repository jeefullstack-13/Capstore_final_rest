package com.cg.BackEndRest.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.BackEndRest.model.Address;

@Repository("addressDao")
@Transactional
public interface AddressDao extends JpaRepository<Address, Integer>{

}
